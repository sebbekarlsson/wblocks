#include "Markdown.h"

std::string Markdown::process(std::string html) {
    return html;
}
